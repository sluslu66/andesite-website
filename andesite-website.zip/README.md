# Andesite Website

A simple static website themed around andesite stone.

## Features
- Clean and minimal design
- Informational sections
- Ready for GitHub deployment

## How to Use
1. Download and extract the zip file
2. Open index.html in your browser

## Author
Mortification Records
